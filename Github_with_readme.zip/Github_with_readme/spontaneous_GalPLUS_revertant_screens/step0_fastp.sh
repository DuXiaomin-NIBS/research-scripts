while read fastq1 fastq2 outname
do
    echo "===$fastq1"
    echo "===$fastq2"
    echo "===$outname"

    out1=$outname"_1.fastq.gz"
    out2=$outname"_2.fastq.gz"

    echo "======$out1"
    echo "======$out2"

    fastp --in1 $fastq1 --in2 $fastq2 --out1 $out1 --out2 $out2 --length_required 70 --html $outname.html --report_title $outname.report --json $outname.json

done < fastp.list

echo "finished"

