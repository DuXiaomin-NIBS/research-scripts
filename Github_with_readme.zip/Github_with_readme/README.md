# Evolutionary Analysis Pipeline Collection

The project consists of three core analysis modules: Copy number variation (CNV) analysis, heatmap visualization of the SNP patterns in a chromosome II region containing the gal cluster in 58 S. pombe natural isolates, and spontaneous Gal+ revertant screens.

## Content

```
├──CNV-JB875_2nd_mel1/          # copy number variation analysis
├──SNP_pattern_analysis_of_the_chromosomeII_gal_cluster_region_in_58Spombe_natural_isolates/          # SNP pattern heatmap analysis
├──spontaneous_GalPLUS_revertant_screens/          # spontaneous screen analysis
└── README.md          # this document
```

## Analysis modules details

### 1. Copy number analysis of JB875_2nd_mel1 (CNV-JB875_2nd_mel1)

#### Overview
This module focuses on analyzing copy number of the JB875_2nd_mel1 in JB875 natural isolate, utilizing sequencing depth analysis to identify CNV regions across the genome.

#### Main analysis workflow

1. **Reads mapping** (`step1_PEmapping_newshamtools.sh`)
2. **Depth analysis** (`step1_samtools_get_chr_window_depth_*.pl`)
3. **Data normalization and visualization** (`step2_draw_depth_and_normalize_5kbwindow-dot_plot.R`)

#### Key Output Files
- `Strain.avg.depth_chrI_essntialgene.txt`: Mean of essential genes depth on chromosome I
- `DXM972_JB875_5kbwindow.avg.depth.txt`: 5kb window depth data
- `DXM972_JB875.avg.depth_normalized.txt`: Normalized depth data

---

### 2. SNP pattern heatmap analysis (SNP_pattern_analysis_of_the_chromosomeII_gal_cluster_region_in_58Spombe_natural_isolates)

#### Overview
This module shows the process used to generate a comprehensive heatmap of SNP patterns in a chromosome II region containing the gal cluster in 58 S. pombe natural isolates.

#### Reference Genome
Uses fission yeast reference genome adding GMC (gal-mel cluster). Contigs include:
- I, II, III: three main chromosomes
- rDNA_distal_contig1/2: rDNA-related regions
- MT: mitochondrial genome
- ninegene: GMC (gal-mel cluster)

#### Main analysis workflow
1. **Reads (filtered) mapping** (`step01_batch_mapping.sh`)
2. **Call variant with GATK HaplotypeCaller** (`step02_call_variant_*.sh`)
3. **Combine GVCF and joint calling** (`step03_combine_genotype.sh`)
4. **Extract SNP** (`step04_extract_snp.sh`)
5. **Extract INDEL** (`step05_extract_indel.sh`)
6. **Extract SNP and INDEL matrix** (`step06_extract_SNP_matrix_from_vcf.pl` and `step06_extract_indel_matrix_from_vcf.pl`)
7. **Combine SNP and INDEL** (`step07_combined_snp_indel_for_all_strain.pl`)
8. **Region-specific extraction** (`step08_extract_gal_region.sh`)
9. **Retain sites including ref and alt allele** (`step09_keep_0_1_site.pl`)
10. **Draw heatmap and get sorted strain list** (`step10_draw_heatmap.R`)
11. **Sort the heatmap input list according to the strain order** (`step11_sort_heatmap_strain_order.pl`)
12. **Draw heatmap with sorted strain list** (`step12_for_ordered_heatmap.R`)

#### Key files
- `sample.list_add_DY43658`: Sample information list
---

### 3. Spontaneous screen analysis (spontaneous_GalPLUS_revertant_screens)

#### Overview
This module provides a complete bioinformatics pipeline for spontaneous Gal+ revertant screens.

#### Main analysis workflow
1. **Data preprocessing** (`step0_fastp.sh`)
2. **Reads mapping** (`Step1_map_bwa_samtools_markdup.sh`)
3. **Variant calling using two softwares samtools and deepvariant** (`Step2_callvariant_samtools.sh` and `Step2_callvariant_deepvariant_version1.3.0.sh`)
4. **Combine all variants and run snpeff** (`Step3_combine_site.sh`)
5. **Depth and reference allele frequency calculation for each sample** (`Step4_bamreadcount.sh`)
6. **Extract snpeff result** (`Step5_snpEff_extract.sh`)
7. **Extract CDS information** (`Step6_construct_anno.sh`)
8. **Data Integration** (`Step7_integrade_parts.sh`)

#### Note
The “Main analysis workflow” highlights the principal driver scripts. All subroutines and supporting scripts referenced therein are available in the “spontaneous Gal+ revertant screens” folder.

---

*Last updated: February 2026*