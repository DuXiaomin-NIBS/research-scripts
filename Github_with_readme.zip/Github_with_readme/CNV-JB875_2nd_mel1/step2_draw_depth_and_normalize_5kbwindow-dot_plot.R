### need change directory
setwd("/Users/duxiaomin/Desktop/5kb_window")  

bedfile <- read.table("DXM972_JB875_HiFi_assembly_window5kb.bed",sep="\t",header=F,stringsAsFactors = F)
midpoint <- as.numeric((bedfile[,2]+bedfile[,3])/2)


mydata <- read.table("DXM972_JB875_5kbwindow.avg.depth.txt",header = T, sep="\t",stringsAsFactors = F)

myrowname <- mydata[,1]
mynewdata <-mydata[,-1]
row.names(mynewdata) <- myrowname

mycolname <- colnames(mynewdata)

xdata <- seq(1,12573)


I_FYPO <- read.table("Strain.avg.depth_chrI_essntialgene.txt",sep="\t",header = T, stringsAsFactors = F)
I_FYPO_row <- I_FYPO[,1];
FYPO_data <- I_FYPO[,-1]


#######################################

pdf("DXM972_JB875.avg.depth_normalized_5kbwindow-V2.pdf",width=20,height=10)
par(mfrow=c(4,1))

for( i in 1:ncol(mynewdata)){
 
  trimmean <- mean(FYPO_data[,i],0.1)
  
  plot(midpoint[1:1121],mynewdata[c(1:1121),i]/trimmean,type='p',pch = 16, col = "black", cex = 0.8,main = paste(mycolname[i],"chr1"),xlim = c(0,5579133),ylim=c(0,5),xlab="",xaxt = "n",ylab="normalized depth")
  #typt"h"是棍状图，"p"是点状图，pch = 16：实心圆点，col = "blue"：黑色点 cex = 0.8：点的大小缩小到 80%
  axis(side=1, at=c(0,1000000,2000000,3000000,4000000,5000000), seq(0,5)) #横坐标标的是0~5，每一个数字代表1M.
  abline(v=c(mean(3753687,3789421)),col="red",lwd=1,lty=3)
  abline(h=c(1,2,3,4),col="gray",lwd=1,lty=3)
  rect(xleft = 42678, ybottom = 0, xright = 43922, ytop = 5, border = "red")
  
  plot(midpoint[1122:2066],mynewdata[c(1122:2066),i]/trimmean,type='p',pch = 16, col = "black", cex = 0.8,main = paste(mycolname[i],"chr2"),xlim = c(0,5579133),ylim=c(0,5),xlab="",xaxt = "n",ylab="normalized depth")
  axis(side=1, at=c(0,1000000,2000000,3000000,4000000), seq(0,4))
  abline(v=c(mean(1602264,1644747)),col="red",lwd=1,lty=3)
  abline(h=c(1,2,3,4),col="gray",lwd=1,lty=3)
  
  plot(midpoint[2067:2583],mynewdata[c(2067:2583),i]/trimmean,type='p',pch = 16, col = "black", cex = 0.8,main = paste(mycolname[i],"chr3"),xlim = c(0,5579133),ylim=c(0,5),xlab="",xaxt = "n",ylab="normalized depth")
  axis(side=1, at=c(0,1000000,2000000), seq(0,2))
  abline(v=c(mean(1070904,1137003)),col="red",lwd=1,lty=3)
  abline(h=c(1,2,3,4),col="gray",lwd=1,lty=3)

 } 
  
  

dev.off()

###################################

finalmatrix <- matrix(0,nrow(mynewdata),ncol(mynewdata))

for( i in 1:ncol(mynewdata)) {

  trimmean <- mean(FYPO_data[,i],0.1)
  inorm <- mynewdata[,i]/trimmean
  
  finalmatrix[,i] <- inorm
  
}

rownames(finalmatrix) <- myrowname
colnames(finalmatrix) <- mycolname

write.table(finalmatrix, file="DXM972_JB875.avg.depth_normalized.txt",sep="\t",quote = FALSE,row.names = TRUE,col.names = TRUE)


  
