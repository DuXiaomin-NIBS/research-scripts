samplelist=(
DY43686
)


for i in ${samplelist[@]}
do
        echo "---------------"
        echo $i
        echo "---------------"

        echo "***Begain bwa mapping"
        # sequenced fastq file
        fastq1=$i"_1.fastq.gz"
        fastq2=$i"_2.fastq.gz"
        echo $fastq1
        echo $fastq2

        # define output basename
        myoutput=$i".fastq"

        # bwa mapping main program
        /home/suofang/Software/bwa-0.7.17/bwa mem -t 8 /data/duxiaomin/CNV-JB875_NGC_mel1-in_DXM972_HiFi_assembly/DXM972_len_total_hifiasm_assembly.reorder_4contigs.fasta $fastq1 $fastq2 > $myoutput.bwa.sam

        echo "***Sam=>Bam=>Sorted=>Index"
        samtools view -@ 4 -bS -o $myoutput.bwa.bam $myoutput.bwa.sam
        samtools sort -@ 4 -O bam -o $myoutput.bwa.sorted.bam $myoutput.bwa.bam
        samtools index $myoutput.bwa.sorted.bam
        rm $myoutput.bwa.sam
        rm $myoutput.bwa.bam



        #echo "***Samtools rmdup"
        samtools rmdup $myoutput.bwa.sorted.bam $myoutput.bwa_rmdup.sorted.bam 2>$myoutput.bwa.rmdup
        samtools index $myoutput.bwa_rmdup.sorted.bam

done


