ref=DY47073_ninegene.fasta

# find all g.vcf filenames into one file
#find . -name "*.g.vcf" > input.list


#################################
# GATK combineGVCFs
java -jar -Xmx10g /home/suofang/Software/GenomeAnalysisTK-3.8-1-0-gf15c1c3ef/GenomeAnalysisTK.jar \
-T CombineGVCFs -R $ref \
--variant input.list \
-o xiaomin_58_strains.g.vcf


#################################
# GATK GenotypeGVCFs
java -jar -Xmx10g /home/suofang/Software/GenomeAnalysisTK-3.8-1-0-gf15c1c3ef/GenomeAnalysisTK.jar \
-T GenotypeGVCFs \
-R $ref \
--variant xiaomin_58_strains.g.vcf \
-o xiaomin_58_strains.all.vcf

echo "step03 done"

