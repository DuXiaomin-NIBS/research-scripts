use strict;

my %all;
open(IN,"<step6_for_heatmap.txt") || die;
my $strain = <IN>;
chomp $strain;
chop $strain if($strain =~ /\r$/);
my @strain = split(/\t/,$strain);

my %site;
my $j = 0;

while (<IN>){
	chomp;
	chop if(/\r$/);
	my @line = split(/\t/);
	$j++;
	$site{$j} = $line[0];
	for (my $n=1; $n<=$#line; $n++){
		$all{$strain[$n]}{$line[0]} = $line[$n];
		
	}
}
close IN;

my %order;
my %des;
open(IN,"<z250604_step6_for_heatmap.txt.order.txt") || die;
while (<IN>){
	chomp;
	chop if(/\r$/);
	my @line = split(/\t/);
	$order{$line[1]} = $line[0];
	$des{$line[1]} = $line[1];
}
close IN;

open(OUT,">z250604_step6_for_ordered_heatmap.txt") || die;
foreach my $i (sort {$a <=> $b} keys %site){
	print OUT "\t$site{$i}";
}
print OUT "\n";
foreach my $istrain(sort {$order{$b} <=> $order{$a}} keys %order){
	print OUT "$des{$istrain}";
	foreach my $isite (sort {$a <=> $b} keys %site) {
		my $tmp = $site{$isite};
		print OUT "\t$all{$istrain}{$tmp}";
	}
	print OUT "\n";
	
}
close OUT;

