samplelist=(
DY10491
DY10495
DY10655
DY15499
DY15500
DY15501
DY15505
DY29152
DY29155
DY29157
DY29158
DY29159
DY29164
DY29165
DY30763
DY34373
DY34374
DY38515
DY38751
DY38761
DY39825
DY39827
DY42495-zxr
DY42500
DY42581
DY42586
DY43646
DY43647
DY43648
DY43649
DY43651
DY43652
DY43653-2308
DY43655
DY43656
DY43657-2308
DY43660
DY43661
DY43663
DY43664-zxr
DY43666
DY43667
DY43669
DY43670
DY43671
DY43672
DY43674
DY43677
DY43678
DY43686-2308
DY43882-zxr
DY43883
DY44512
DY44515-zxr
DY44516-zxr
DY44517-zxr
DY44518-zxr
DY5945
DY43658
)



for i in ${samplelist[@]}
do
echo "----------------------"
ID=$i;
echo $ID;
echo "----------------------"

ref="DY47073_ninegene.fasta"
# GATK HaplotypeCaller
# -R -I --emitRefConfidence  --variant_index_type --variant_index_parameter -mbq  -stand_call_conf  -nct -o
java -jar -Xmx10g /home/suofang/Software/GenomeAnalysisTK-3.8-1-0-gf15c1c3ef/GenomeAnalysisTK.jar \
-T HaplotypeCaller \
-R $ref -I ${ID}.dedup.bam \
--emitRefConfidence GVCF \
--variant_index_type LINEAR \
--variant_index_parameter 128000 \
-mbq 20 \
-stand_call_conf 20 \
-o $ID.raw.g.vcf

done
echo "finished"


