############### build reference kinds of index
#bwa index $ref
#samtools faidx $ref
#tmpname=${ref%.*} #去除扩展名
#java -jar /home/suofang/Software/picard_2.23.3.jar CreateSequenceDictionary REFERENCE=$ref OUTPUT=$tmpname.dict

# for current BOE project, only pombe reference is used. The index files are build in advance.

ref="../pombe_ASM294v1_18_toplevel.fasta"

# store all result for this step
if [ ! -d "mapping" ]
then
     mkdir mapping
fi

while read fastq1 fastq2 sample
do
    echo "------------$sample------------"
    ##################################################                 
    # bwa mem mapping

    ID=$sample
    LB=$ID
    PL=ILLUMINA
    SM=$ID

    readgroup="@RG\tID:"$ID"\tLB:"$LB"\tPL:"$PL"\tSM:"$SM
    bwa mem -t 8 -M -R $readgroup $ref $fastq1 $fastq2 > mapping/${sample}.bwa.sam

	echo "start SortSam ...."
	# sort coordinate
	java -jar /home/suofang/Software/picard_2.17.11.jar SortSam INPUT=mapping/${sample}.bwa.sam OUTPUT=mapping/${sample}.bwa.sorted.bam SORT_ORDER=coordinate

	echo "Start MarkDuplicates ..."
	# MarkDuplicates
	java -jar /home/suofang/Software/picard_2.17.11.jar MarkDuplicates INPUT=mapping/${sample}.bwa.sorted.bam OUTPUT=mapping/${sample}.bwa_rmdup.sorted.bam METRICS_FILE=mapping/${sample}.dedup.bam.metrics.txt ASSUME_SORTED=true
	java -jar /home/suofang/Software/picard_2.17.11.jar BuildBamIndex INPUT=mapping/${sample}.bwa_rmdup.sorted.bam OUTPUT=mapping/${sample}.bwa_rmdup.sorted.bam.bai

	echo "Start Collect Metrics..."
	# Collect Alignment & Insert Size Metrics
	java -jar /home/suofang/Software/picard_2.17.11.jar CollectAlignmentSummaryMetrics R=$ref I=mapping/${sample}.bwa.sorted.bam O=mapping/${sample}.alignment_metrics.txt
	java -jar /home/suofang/Software/picard_2.17.11.jar CollectInsertSizeMetrics INPUT=mapping/${sample}.bwa.sorted.bam OUTPUT=mapping/${sample}.insert_metrics.txt HISTOGRAM_FILE=mapping/${sample}.insert_size_histogram.pdf


done < config.list

echo "Step1: mapping finished"
