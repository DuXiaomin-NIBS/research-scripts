setwd("E:/personal_duxiaomin/20241106_paper/5_redo_heatmap_NGC-ref/20250604_range_II_4467516_4492129")
rm(list=ls())
library(gplots)

ifile <- "z250604_step6_for_heatmap.txt"
mydata <- read.table(ifile, header = T, sep="\t", stringsAsFactors = F)
anno1 <- as.character(readLines("anno_color.txt"))

myrowname <- mydata[,1]
mydata2<- mydata[,-1]
row.names(mydata2) <- myrowname

mybreaks <- c(-1.25,-0.75,-0.25,0.25,0.75,1.25,1.75)

mycol <- c("gray","orange3","lemonChiffon","orange","forestgreen","thistle1")
#mycol <- c("gray","orange3","red","orange","yellow","thistle1")
pdf("z250604_step6_for_heatmap_row.txt.pdf")

h<-heatmap.2( t(as.matrix(mydata2)),
           dendrogram ="row",trace="none",Colv=F,Rowv=T,
           key=T,key.title=NA,keysize =4,key.xlab = NA,
           key.xtickfun = function() {
             breaks = pretty(parent.frame()$breaks)
             breaks = mybreaks
             list(at = parent.frame()$scale01(breaks),
             labels = breaks)},
           na.color="gray",key.par=list(mar=c(3,1,2,1)),
           col = mycol,
           symkey=T,breaks = mybreaks,main="Gal gene deletion\ndeleteion area:4467518-4492116\n",
            ColSideColors = anno1,
           lwid=c(1, 10),lhei= c(1, 6),
           margins = c(5, 7),cexRow=0.65,cexCol=0.3,
           offsetRow=0.1          
           )

dev.off()

myorder <- rownames(t(mydata2))[h$rowInd]
write.table(myorder,file=paste(ifile,".order.txt",sep = ""),quote = FALSE,sep="\t",col.names = F)


#symbreaks=F,density.info='none',
#lwid=c(1, 10),lhei= c(1, 6),
#margins = c(5, 6),cexRow=0.65,cexCol=0.3,
#offsetRow=0.1,ColSideColors = anno1,
#key.xtickfun = function() {
#  breaks = pretty(parent.frame()$breaks)
#  breaks = mybreaks
#  list(at = parent.frame()$scale01(breaks),
#       labels = breaks)
#key.xlab=NA,
#key.par=list(mar=c(3,1,2,1)),

  
  