use strict;

my %all;

my %snp;
open(IN,"<xiaomin_58.passed_snps_select1.matrix_allsites.txt") || die;
my $title1 = <IN>;
chomp $title1;
chop $title1 if($title1 =~ /\r$/);
while (<IN>){
	chomp;
	chop if(/\r$/);
	my @line = split(/\t/);
	$all{$line[0]}{$line[1]} = 1;
	$snp{$line[0]}{$line[1]} = $_;
}
close IN;

my %indel;
open(IN,"<xiaomin_58.passed_indel_select1.matrix_allsites.txt") || die;
my $title2 = <IN>;
chomp $title2;
chop $title2 if($title2 =~ /\r$/);
while (<IN>){
	chomp;
	chop if(/\r$/);
	my @line = split(/\t/);
	$all{$line[0]}{$line[1]} = 1;
	$indel{$line[0]}{$line[1]} = $_;
}
close IN;

open(OUT,">step3_SNP_INDEL_combine_matrix_allstrain.txt") || die;
if($title1 eq $title2){
	print OUT "$title1\n";
}

foreach my $ichr (sort keys %all){
	foreach my $ipos (sort {$a <=> $b} keys %{$all{$ichr}}){
		if(exists($snp{$ichr}{$ipos})){
			print OUT "$snp{$ichr}{$ipos}\n";
		}
		
		if(exists($indel{$ichr}{$ipos})){
			print OUT "$indel{$ichr}{$ipos}\n";
		}
	}
}


close OUT;



