# below are the coordinates of gal region

# below are pombe reference genome 
#awk '$1=="II" && $2>=4467516 && $2<=4492129' step3_SNP_INDEL_combine_matrix_allstrain.txt | awk '$4!~/,/' > 20250604_extract_II_4467516_4492129.txt

# DY47073 as reference genome
awk '$1=="II" && $2>=4567597 && $2<=4644548' step3_SNP_INDEL_combine_matrix_allstrain.txt | awk '$4!~/,/' > 20250604_extract_II_4567597_4644548_DY47073.txt
cat step3_SNP_INDEL_combine_matrix_allstrain.txt.header 20250604_extract_II_4567597_4644548_DY47073.txt > 20250604_extract_II_4567597_4644548_DY47073.header.txt


