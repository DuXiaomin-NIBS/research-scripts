
while read read1 read2 sample
do 
	echo "$sample";
	sh step01_mapping_and_markdup_clu01_20201021.sh $read1 $read2 $sample

done < sample.list_add_DY43658

echo "finished"
