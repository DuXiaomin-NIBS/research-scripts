use strict;

my $n_sites = 0;
my $n_moreallele = 0;
my $n_filtersite = 0;
my $n_heterfilter_depth0 = 0;

my %heter;
my %homo;
my %ref;


my @title;

open(IN,"<../xiaomin_58.passed_indel_select1.vcf") || die;
open(OUT,">xiaomin_58.passed_indel_select1.matrix_allsites.txt") || die;
while (<IN>) {
	chomp;
	chop if(/\r$/);
	next if(/^\#\#/);
	
	
	if(/^\#CHROM/){
		@title = split(/\t/);
		print OUT "chr\tpos\tref\tsnp";
		for (my $n=9;$n<=$#title ;$n++) {
			print OUT "\t$title[$n]";
		}
		print OUT "\n";
	}else{
		$n_sites++;
		my @line = split(/\t/);
		
		#########################
		if(length($line[4]) != 1){# remove this site like A -> C,T
			$n_moreallele++;
			#next;
		}
		
		#########################
		my $mark = 0;
		for (my $n=9;$n<=$#line; $n++) {
			my @tmp = split(/:/,$line[$n]);
			if ($tmp[0] eq "./.") {
				$mark = 1;  # remove this site containing "./.";
			}
		}
		if ($mark == 1) {
			$n_filtersite++;
			#next;
		}
		
		########################
		my $mark1 = 0;
		for (my $n=9;$n<=$#line;$n++) {
			my @tmp = split(/:/,$line[$n]);
			my @ad = split(/\,/,$tmp[1]);
			if($tmp[0] eq "0/1" && $ad[0] + $ad[1] == 0){  # remove this site like 0/1:0,0
				$mark1 =1;
			}
		}
		if ($mark1 == 1) {
			$n_heterfilter_depth0++;
			#next;
		}
		
		########################
		print OUT "$line[0]\t$line[1]\t$line[3]\t$line[4]";
		for (my $n=9; $n <= $#line ;$n++) {
			my @tmp = split(/:/,$line[$n]);
			my @ad = split(/\,/,$tmp[1]);
			if($tmp[0] eq "0/0"){ ######################0/0 => 0
				$ref{$title[$n]}++;
				print OUT "\t0";
			}elsif($tmp[0] eq "1/1"){ ####################1/1 => 1
				$homo{$title[$n]}++;
				print OUT "\t1";
			}elsif($tmp[0] eq "0/1"){
				if(($ad[0]+$ad[1]) == 0){ #################0/1 but depth=0 => -0.5
					print OUT "\t-0.5";
				
				}else{
					my $freq = $ad[1]/($ad[0]+$ad[1]);     ####### 0/1 but depth != 0  => 0.5
					if($freq>=0.2 && $freq<=0.8){
						print OUT "\t0.5";
						$heter{$title[$n]}++;
					}elsif($freq > 0.8){
						$homo{$title[$n]}++;
						print OUT "\t1";
					}elsif($freq < 0.2){
						$ref{$title[$n]}++;
						print OUT "\t0";
					}
				}
			}elsif($tmp[0] eq "./."){
				print OUT "\t-1";    ############## ./. => -1
			}else{
				print OUT "\t1.5"; ############### other case => 1.5
			}
		}

		print OUT "\n";

	}
}
close IN;
close OUT;

open(OUT2,">step1_sites_indel_statistics.txt") || die;
print OUT2 "n_sites (vcf total sites)\t$n_sites\n";
print OUT2 "n_moreallele (more allele in one site)\t$n_moreallele\n";
print OUT2 "n_filtersite (at least one nocall in one strain)\t$n_filtersite\n";
print OUT2 "n_heterfilter_depth0 (remove the sites like 0/1, but depth is 0,0)\t$n_heterfilter_depth0\n";
close OUT2;

# open(OUT1,">Z_our_strains.passed_snps_select1.hetersite.txt") || die;
# for (my $n=9;$n<=$#title ;$n++) {
	# print OUT1 "$title[$n]\t$ref{$title[$n]}\t$homo{$title[$n]}\t$heter{$title[$n]}\n";
# }

# close OUT1;
