
##################################################                 
# parameters

fastq1=$1
fastq2=$2
ID=$3
SM=$ID
LB=DuLab
PL=ILLUMINA
PU=$ID
ref="DY47073_ninegene.fasta"
readgroup="@RG\tID:"$ID"\tLB:"$LB"\tPL:"$PL"\tSM:"$SM"\tPU:$PU"



#/home/suofang/software/bwa-0.7.17/bwa index $ref
#java -jar /home/suofang/software/picard_2.17.11.jar CreateSequenceDictionary REFERENCE=$ref OUTPUT=$ref.dict

# bwa mem mapping
echo "start bwa mapping ..."
bwa mem -t 8 -M -R $readgroup $ref $fastq1 $fastq2 > $ID.sam

echo "start SortSam ...."
# sort coordinate
java -jar /home/suofang/Software/picard_2.17.11.jar SortSam INPUT=$ID.sam OUTPUT=$ID.bam SORT_ORDER=coordinate

echo "Start Collect Metrics..."
# Collect Alignment & Insert Size Metrics
#java -jar /home/suofang/Software/picard_2.17.11.jar CollectAlignmentSummaryMetrics R=$ref I=$ID.bam O=$ID.alignment_metrics.txt
#java -jar /home/suofang/Software/picard_2.17.11.jar CollectInsertSizeMetrics INPUT=$ID.bam OUTPUT=$ID.insert_metrics.txt HISTOGRAM_FILE=$ID.insert_size_histogram.pdf
           #samtools depth -a sorted_reads.bam > depth_out.txt 

echo "Start MarkDuplicates ..."
# MarkDuplicates
java -jar /home/suofang/Software/picard_2.17.11.jar MarkDuplicates INPUT=$ID.bam OUTPUT=$ID.dedup.bam METRICS_FILE=$ID.dedup.bam.metrics.txt ASSUME_SORTED=true
java -jar /home/suofang/Software/picard_2.17.11.jar BuildBamIndex INPUT=$ID.dedup.bam


rm $ID.sam
rm $ID.bam

