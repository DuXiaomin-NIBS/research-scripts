ref=DY47073_ninegene.fasta

# ---------only keep indel
java -jar -Xmx10g /home/suofang/Software/GenomeAnalysisTK-3.8-1-0-gf15c1c3ef/GenomeAnalysisTK.jar \
-T SelectVariants \
-R $ref \
-V xiaomin_58_strains.all.vcf \
-selectType INDEL \
-o xiaomin_58_indel.vcf


java -jar -Xmx10g /home/suofang/Software/GenomeAnalysisTK-3.8-1-0-gf15c1c3ef/GenomeAnalysisTK.jar \
-T VariantFiltration \
-R $ref \
-V xiaomin_58_indel.vcf \
--filterExpression "QD < 2.0 || FS > 60.0 || MQ < 40.0" --filterName "my_snp_filter" \
-G_filter "DP<10" -G_filterName "lowiDP" \
-o xiaomin_58.indelfilter.vcf

# QD : QualByDepth
# FS : FisherStrand
# MQ : RMSMappingQuality

java -jar -Xmx10g /home/suofang/Software/GenomeAnalysisTK-3.8-1-0-gf15c1c3ef/GenomeAnalysisTK.jar \
-T VariantFiltration \
-R $ref \
-V xiaomin_58.indelfilter.vcf \
--setFilteredGtToNocall \
-o xiaomin_58.indelfilter.nocall.vcf



java -jar -Xmx10g /home/suofang/Software/GenomeAnalysisTK-3.8-1-0-gf15c1c3ef/GenomeAnalysisTK.jar \
-T SelectVariants \
-R $ref \
-V xiaomin_58.indelfilter.nocall.vcf \
--excludeFiltered \
-o xiaomin_58.passed_indel_select1.vcf




