use strict;

open(IN,"<step6_for_heatmap.txt") || die;
open(OUT,">z250604_step6_for_heatmap.txt") || die;
my $title = <IN>;
print OUT "$title";
while(<IN>){
	chomp;
	chop if(/\r$/);
	my @line = split(/\t/);
	print OUT "$line[0]";
	for(my $n=1; $n<=$#line; $n++){
		if($line[$n] eq "0" || $line[$n] eq "1"){
			print OUT "\t$line[$n]";
		}else{
			print OUT "\tNA";
		}
	}
	print OUT "\n";
}
close IN;
close OUT;


